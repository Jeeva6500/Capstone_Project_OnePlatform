package com.natwest.exception;

public class CardNumberDoesNotExist extends Exception{
	
	public CardNumberDoesNotExist(String msg) {
		super(msg);
	}
	
	public CardNumberDoesNotExist() {}


}
