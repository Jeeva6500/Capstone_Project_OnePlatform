package com.natwest.exception;

public class CardNumberAlreadyExist extends Exception{
	
	public CardNumberAlreadyExist(String message) {
		super(message);
	}
	
	public CardNumberAlreadyExist() {}

}
