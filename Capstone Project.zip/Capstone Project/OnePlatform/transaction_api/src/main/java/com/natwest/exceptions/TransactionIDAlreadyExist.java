package com.natwest.exceptions;

public class TransactionIDAlreadyExist extends Exception{
	public TransactionIDAlreadyExist(String message) {
		super(message);
		
		
	}
	
	public TransactionIDAlreadyExist() {}

}
