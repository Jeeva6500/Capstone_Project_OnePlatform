# Capstone_Project_OnePlatform
Customer can hold accounts and Credit card with any bank. They can add all in this app and manage their accounts and transactions seamlessly.
