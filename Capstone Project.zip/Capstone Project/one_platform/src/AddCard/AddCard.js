// import React from 'react'
import { Button, FilledInput, FormControl, IconButton, InputAdornment, InputLabel, OutlinedInput, Snackbar, TextField } from '@mui/material'
import axios from 'axios'
import backgroudimg1 from "../Images/bg_1@2x.png"
import creditcard1 from "../Images/creditcard1.jpg"
import addcard from "../Images/addcard.png"
import { useFormik } from 'formik'
import React, { useState } from 'react'
import * as yup from 'yup'
import { useNavigate } from 'react-router-dom'
import CloseIcon from '@mui/icons-material/Close'
import YupPassword from 'yup-password'
YupPassword(yup)


export default function AddCard() {
    const token = localStorage.getItem("mytoken");
    const nav = useNavigate();
    const [error, setError] = useState('')
    const navigate = useNavigate();
    const [err, setErr] = useState('');
    const [open, setOpen] = useState(false);
    //let cardNumber = (JSON.parse(localStorage.getItem('cardNo')))
  
    const handleClose = () => {
        setOpen(false)
        nav('/accounts')
        return;
    }

    const action = (
        <React.Fragment>
            <IconButton size='small' color='inherit' onClick={handleClose}>
                <CloseIcon></CloseIcon>
            </IconButton>
        </React.Fragment>
    )

    const formik = useFormik({
        initialValues: {
            cardNo: '',
            cardLimit: '100000',
            cardSpent: '500',
            cardBalance: '99500',
            expiryDate:'',
            cvv:'',
            accountNo:(JSON.parse(localStorage.getItem('accountNo'))),

            
        },
        onSubmit: values => {
                                axios.post("http://localhost:8080/api/card/add",values, {
                                headers: {
                                "Authorization": `Bearer ${token}`
                                 }
                                    })
                                        .then(result => {
                                            //this.setState({setExist:result.data})
                                            //console.log("else executed");
                                            setOpen(true)
                                            
                                            
                                        })
                                        .catch(error => {
                                            console.log(error);
                                            setError(error.response.data)});
                                    
        },
        validationSchema: yup.object().shape({
            cardNo: yup.string().min(16).max(16, "Enter valid Card No").required('Card No cannot be blank'),
            cardLimit: yup.string().required('Card limit cannot be blank'),
            cardSpent: yup.string().required('Card spent cannot be blank'),
            cardBalance: yup.string().required('Card spent cannot be blank'),
            accountNo: yup.string().min(8).max(16, "Enter valid Account No").required('Account No cannot be blank'),
            expiryDate:yup.date().required('Expiry date cannot be blank'),
            cvv: yup.string().min(3).max(3, "Enter valid 3 digit CVV").required('CVV cannot be blank'),
         })
    })

    return (
        <div className="foi-header landing-header " id="loginpagebg" style={{backgroundImage:`url(${backgroudimg1}),url(${creditcard1})`}}>
        <div className='container'>
            <div className="row">
                <div className="col-md-4 offset-md-4">
                    <div className='card'>
                        <div className="text-white  mb-2 p-2 rounded text-center" style={{ background: "indigo" }}>
                            <h4>Link card</h4>
                            {
                                err != '' ? <span className='text-center alert alert-danger'>{error}</span> : <span></span>
                            }
                        </div>
                        <span className='text-center text-danger'>{error}</span> <br></br>
                        <form onSubmit={formik.handleSubmit}>

                        <div className="row">
                            
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }} onBlur={formik.handleBlur} onChange={formik.handleChange} name='cardNo' id="cardNo" label="Card Number*" variant="outlined" />
                                    {
                                        formik.errors.cardNo && formik.touched.cardNo ?
                                            <p className='text-danger'>{formik.errors.cardNo}</p> : null
                                    }
                                   
                                </div>
                            </div>

                            <div className="row">
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }} onBlur={formik.handleBlur} onChange={formik.handleChange} name='expiryDate' id="expiryDate" label="Expiry Date* (yyyy-mm-dd)" variant="outlined" />
                                    {
                                        formik.errors.expiryDate && formik.touched.expiryDate ?
                                            <p className='text-danger'>{formik.errors.expiryDate}</p> : null
                                    }
                                </div>
                            </div>

                            <div className="row">
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }}onBlur={formik.handleBlur} onChange={formik.handleChange} name='cvv' id="cvv" label="CVV*" variant="outlined" />
                                    {
                                        formik.errors.cvv && formik.touched.cvv ?
                                            <p className='text-danger'>{formik.errors.cvv}</p> : null
                                    }
                                </div>
                            </div>

                            

                            
                            <div className="row">
                                <div className="col text-center mb-4 ">
                                    <div className='font-weight-bold'>
                                    <Button type='submit' variant="contained" id="mainbutton1" style={{background:"indigo",fontWeight:"bold" }}>Add</Button>
                                </div>
                                </div>
                            </div>

                        </form>

                    </div>
                    <br></br>
                    <Snackbar
                        open={open}
                        autoHideDuration={2000}
                        onClose={handleClose}
                        message="Card added successfully"
                        action={action}
                    />
                </div>
            </div>
        </div>
        </div>
    )
}
