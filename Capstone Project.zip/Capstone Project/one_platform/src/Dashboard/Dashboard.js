import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import dashboardimg2 from "../Images/dashboardimg2.jpg"

import { Link } from 'react-router-dom';
export default function Dashboard() {

  const token = localStorage.getItem("mytoken");
  const customerId = localStorage.getItem("customerId");


  useEffect(() => {
    fetch(`http://localhost:8080/api/accounts/getaccount/${customerId}`, {
        headers: {
            'Content-Type': 'application/json',
            "Authorization": `Bearer ${token}`
               
        }
    })
        .then(res => res.json())
        .then((data) => {
          console.log("account", data)
            localStorage.setItem('accountNo', data[0].accountNo);
            localStorage.setItem("accountData",JSON.stringify(data))
        }).then(()=>{
          fetch(`http://localhost:8080/api/card/getcard/${localStorage.getItem('accountNo')}`, {
            headers: {
                'Content-Type': 'application/json',
                "Authorization": `Bearer ${token}`
            }
        })
            .then(res => res.json())
            .then((data) => {
              console.log("card", data)
                localStorage.setItem("cardData",JSON.stringify(data))
                localStorage.setItem('CardNumber', data[0].cardNo);
                localStorage.setItem('CardBalance', data[0].cardBalance);
                localStorage.setItem('CardSpent', data[0].cardSpent);
                localStorage.setItem('CardLimit', data[0].cardLimit);
            })
            .then(()=>{
              fetch(`http://localhost:8080/api/transaction/gettransaction/${localStorage.getItem('cardNo')}`, {
                headers: {
                    'Content-Type': 'application/json',
                    "Authorization": `Bearer ${token}`
                }
            })
                .then(res => res.json())
                .then((data) => {
                  console.log("transaction", data)
                    localStorage.setItem("transactionData",JSON.stringify(data))
                })
              })
        })
  },)
  useEffect(() => {
   
  },)
 
  return (
    <div className='bodydashboard' style={{backgroundImage:`url(${dashboardimg2})`}}>
<header>
  <h4 className='text-center'>Welcome Jeeva!</h4>
  <nav id="sidebarMenu" className="collapse d-lg-block sidenav sidebar collapse bg-white" style={{width: "15vw", background: "indigo"}}>
    <div className="position-sticky" >
      <div className="list-group dashboardnavfoc list-group-flush mx-3 mt-4" >
        <Link to='/dashboard' className="list-group-item list-group-item-action py-2 ripple " aria-current="true" style={{background: "indigo", color: "white"}}>
          <span>Dashboard</span>
        </Link>
        <Link to='/accounts' className="list-group-item list-group-item-action py-2 ripple " aria-current="true" style={{background: "indigo", color: "white"}}>
          <span>Show Accounts</span>
        </Link>
        <Link to='/transaction' className="list-group-item list-group-item-action py-2 ripple " aria-current="true" style={{background: "indigo", color: "white"}}>
          <span>Show Transactions</span>
        </Link>
        <Link to='/profile' className="list-group-item list-group-item-action py-2 ripple " aria-current="true" style={{background: "indigo", color: "white"}}>
          <span>My Profile</span>
        </Link>
        
      </div>
    </div>
  </nav>
 
</header>
<main style={{"margin-top": "270px"}}>
  <div className="container pt-4"></div>
  </main>
    </div>
  )
}

   
        