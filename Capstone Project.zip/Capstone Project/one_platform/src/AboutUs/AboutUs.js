import * as React from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import CardActions from '@mui/material/CardActions';
import Button from '@mui/material/Button';
import CardHeader from '@mui/material/CardHeader';
import Avatar from '@mui/material/Avatar';
import { blue, } from '@mui/material/colors';
import Grid from '@mui/material/Unstable_Grid2';
export default function AboutUs() {
  return (
    <><Card sx={{ display: 'flex' }}>
      <Box sx={{}}>
        <CardContent sx={{}}>
        <Typography component="div" variant="h4" style={{ marginTop: "5px", marginBottom: "8px"}}>
        <strong>About us</strong>   
        </Typography>
        <Typography variant="subtitle1" component="div">
  Paypro provides the <span style={{ fontWeight: "bold"}}>platform to have different bank accounts</span>. Our main aim is to provide the platform so that the customer can access all the bank accounts from the same application . The platform will provide the options for using all the banking features of the bank like account management ,transaction history,credit card management and more.
</Typography>
        </CardContent>
        <CardActions>
        <button style={{ width: "120px", height: "50px", backgroundColor: "indigo", color: "white", display: "flex", alignItems: "center", justifyContent: "center", border: "none" }}>
        <strong>At a Glance</strong>    
        </button>
        </CardActions>
      </Box>
      <CardMedia
      component="img"
      sx={{ width: 200 }}
      height={200 }
      image="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRorQca4hd1XEY-MJ2gSlC0KC538BZeQ3d92w&usqp=CAU" />
    </Card><div className="container">
        < mainFeaturedPost />
        <Grid container spacing={2} mt={5}>
        <Grid xs={12}
              sm={6}
              lg={4}>
    <Card sx={{ maxWidth: 345, ml: 5, height: "400px" }}>
      <CardHeader
        avatar={
          <Avatar sx={{ bgcolor: 'indigo' }} aria-label="service">
            P
          </Avatar>
        }
        title="Account Management"
      />
      <CardMedia
        component="img"
        height="194"
        image="https://www.mindgate.solutions/wp-content/uploads/2019/08/adopt-digital-transaction.jpeg"
        alt="Banking"
      />
      <CardContent>
        <Typography variant="body2" >
        PayPro provides the customers with service of adding the account, adding a card and making transactions.
        </Typography>
      </CardContent>
    </Card>
  </Grid>
    {/* Second card starts */}
    <Grid xs={12}
              sm={6}
              lg={4}>
    <Card sx={{ maxWidth: 345, ml: 5, height: "400px" }}>
      <CardHeader
        avatar={
          <Avatar sx={{ bgcolor: 'indigo' }} aria-label="service">
            P
          </Avatar>
        }
        title="Credit Card Service"
      />
      <CardMedia
        component="img"
        height="194"
        image="https://www.knowyourpayments.com/wp-content/uploads/2016/05/transaction-basics-icon@2x-1.png"
        alt="Leadership"
      />
      <CardContent>
        <Typography variant="body2" >
        PayPros's priority is maintaing best relationship with the customer by giving the service at the click
        </Typography>
      </CardContent>
     </Card>
  </Grid>
    {/* Third Card starts */}
    <Grid xs={12}
              sm={6}
              lg={4}>
    <Card sx={{ maxWidth: 345, ml: 5, height: "400px" }}>
      <CardHeader
        avatar={
          <Avatar sx={{ bgcolor: 'indigo' }} aria-label="service">
          P
          </Avatar>
        }
        title="Transaction"
      />
      <CardMedia
        component="img"
        height="194"
        image="https://fedmobile.federalbank.co.in/wp-content/uploads/2020/07/fed_transfer_fund.svg"
        alt="Together"
      />
      <CardContent>
        <Typography variant="body2" >
        Pay Pro builds strong relationships with customers. Customers are at the heart of our workforce.
        </Typography>
      </CardContent>
    </Card>
  </Grid>
    </Grid>
      </div></>
  );
}
