import emailjs from "emailjs-com";
import React from 'react';
export default function ContactUs() {
  function sendEmail(e){
    e.preventDefault();
    emailjs.sendForm('service_ta41ocg', 'template_uzv7our', e.target, 'WkOQk_LE24ZVgipiW').then(res=>{
      console.log(res);
    }).catch(err=> console.log(err));
  }
    return (
      <div className='container border'
      style={{marginTop:"50px",
      width: "50%",
      backgroundImage:`url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjhcV5fBlzpuGByvH-vtbcyah8SxD5_fjZsM7vQFWW&s')`,
      backgroundPosition: "center",
      backgroundSize:"cover",
      }}>
      <h3 style={{marginTop:'25px', textAlign:"center", color: "indigo"}}>Contact us</h3>
      <form className='row' style={{margin:"25px 85px 75px 100px" }} onSubmit={sendEmail}>
        <label>Name</label>
        <input type='text' name='NatWest' className='form-control'/>
        <label>Email</label>
        <input type='email' name='user_email' className='form-control' />
        <label>Message</label>
        <textarea name='message' rows='4' className='form-control text-center'/>
        <input type='submit' value='Send' className='form-control btn btn-primary text-bold text-center'
         style={{marginTop:"20px", backgroundColor: "indigo", color: "white", width:"10vw", marginLeft:"12vw", fontSize:"bold"}}
         />
      </form>
      </div>
    )
  }