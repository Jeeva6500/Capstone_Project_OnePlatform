
import payprologo from "../Images/payprologo.jpg"
import app_1 from "../Images/app_1.png"
import ios from "../Images/ios.svg"
import android from "../Images/android.svg"
import backgroudimg1 from "../Images/bg_1@2x.png"
import backgroundimg2 from "../Images/Bg_2@2x.png"
import app_3 from "../Images/app_3.gif"
import React, { useEffect, useState } from 'react'
import Home from "../Home/Home"

export default function Header() {
    function logout() {
        localStorage.clear("mytoken");
    }
    const [current, setCurrent] = useState('');

    useEffect(() => {
        let status = localStorage.getItem('mytoken');
        setCurrent(status);
    }, [])


    return (
        <div>
            {!localStorage.getItem("mytoken") ?
                <>
                    <div className="container-fluid">
                        <nav className="navbar navbar-expand-lg navbar-light foi-navbar">
                            <a className="navbar-brand" href="/home">
                                <img src={payprologo} style={{ height: '10vh', width: "9vw" }} alt="PayPro" id='payprologo' />
                            </a>
                            <button className="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation">
                                <span className="navbar-toggler-icon"></span>
                            </button>
                            <div className="collapse navbar-collapse" id="collapsibleNavId">
                                <ul className="navbar-nav mr-auto mt-2 mt-lg-0">
                                    <li className="nav-item active">
                                        <a className="nav-link" href="/home" >Home <span className="sr-only">(current)</span></a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="/aboutus">About us</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="features.html">Features</a>
                                    </li>
                                    <li className="nav-item dropdown">
                                        <a className="nav-link dropdown-toggle" href="#" id="pagesMenu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pages</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="/contactform">
                                            Contact us</a>
                                    </li>
                                </ul>
                                <ul className="navbar-nav mt-2 mt-lg-0">
                                    <li className="nav-item mr-2 mb-3 mb-lg-0">
                                        <a className="btn btn-secondary text-light" href="/register" type="submit" style={{ background: "indigo" }}>Sign up</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="btn btn-secondary text-light" href="/login" type="submit" style={{ background: "indigo" }} >Login</a>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </>
                : null}

            {localStorage.getItem("mytoken") ?
                <>
                    <div className="container-fluid">
                        <nav className="navbar navbar-expand-lg navbar-light foi-navbar">
                            <a className="navbar-brand">
                                <img src={payprologo} style={{ height: '10vh', width: "9vw" }} alt="PayPro" id='payprologo' />
                            </a>
                            <button className="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation">
                                <span className="navbar-toggler-icon"></span>
                            </button>
                            <div className="collapse navbar-collapse" id="collapsibleNavId">
                                <ul className="navbar-nav mr-auto mt-2 mt-lg-0">
                                    <li className="nav-item active">
                                        <a className="nav-link" href="/dashboard" >Dashboard <span className="sr-only">(current)</span></a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="/addaccount">Link account</a>
                                    </li>

                                    <li className="nav-item">
                                        <a className="nav-link" href="/addcard">Link cards</a>
                                    </li>

                                    <li className="nav-item active">
                                        <a className="nav-link" href="/accounts" >Show Accounts <span className="sr-only">(current)</span></a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="/makepayment">Make Payment</a>
                                    </li>
                                    
                                    <li className="nav-item">
                                        <a className="nav-link" href="/transaction">Transactions</a>
                                    </li>
                                    
                                    <li className="nav-item">
                                        <a className="nav-link" href="/profile">Profile</a>
                                    </li>
                                </ul>
                                <ul className="navbar-nav mt-2 mt-lg-0">
                                    <li className="nav-item">
                                        <a className="btn btn-secondary text-light" onClick={logout} href="/login" type="submit" style={{ background: "indigo" }} >Logout</a>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </>
                : null}
        </div>

    )
}

