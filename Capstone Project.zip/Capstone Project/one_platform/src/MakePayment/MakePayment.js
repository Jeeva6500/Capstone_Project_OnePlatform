import React from 'react'
import { Alert, IconButton, Snackbar } from '@mui/material'
import axios from 'axios'
import { useFormik } from 'formik'
import { useState } from 'react'
import CloseIcon from '@mui/icons-material/Close'
import { Button, TextField } from '@mui/material'
import Paynow from "../Images/Paynow.jpg"
import { useNavigate } from 'react-router-dom';
import backgroudimg1 from "../Images/bg_1@2x.png"
import payment from "../Images/payment.jpg"
import * as yup from 'yup'
import YupPassword from 'yup-password'
YupPassword(yup)


export default function MakePayment() {
    const navigate = useNavigate();
    const [err, setErr] = useState("");
    const [open, setOpen] = useState(false);
    const [exist, setExist] = useState("");
    const balance= localStorage.getItem('cardBalance');
    const token = localStorage.getItem("mytoken");
    let cardNumber = (JSON.parse(localStorage.getItem('cardNo')))
    const cardBalance = 0;
    const handleClose = () => {
        setOpen(false)
        navigate('/transaction')
        return;
    }

    const action = (
        <React.Fragment>
            <IconButton size='small' color='inherit' onClick={handleClose}>
                <CloseIcon></CloseIcon>
            </IconButton>
        </React.Fragment>
    )

    const formik = useFormik({
        initialValues: {
            cardNo: (localStorage.getItem('cardNo')),
            transactionType: 'Debit',
            transactionAmount: '',
            transactionDesc: '',
          
        }, 
        onSubmit: values => {
            console.log(localStorage.getItem('cardNo'));
            //values.transactionAmount= values.debit*values.Quantity
            console.log(values.cardNo);
            //if (values.transactionAmount>(localStorage.getItem('CardBalance'))){
                //alert("Insufficient balance")
                //setExist({
                 //   text:'Insufficient balance'
                 //   })
           // } else{
                axios.post('http://localhost:8080/api/transaction/add', values, {
                    headers: {
                        "Authorization": `Bearer ${token}`
                         }
                })
            .then(result => {
                //cardBalance = localStorage.getItem(('CardBalance')-(result.data.transactionAmount))
                //localStorage.setItem("TransactionAmount", result.data[0].transactionAmount)
                setOpen(true);


            })
            .catch(error => setErr(error))
       // }
            
        },
        validationSchema: yup.object().shape({
            transactionType: yup.string().required('Transaction type cannot be blank'),
            transactionAmount: yup.number().required('Amount cannot be blank'),
            transactionDesc: yup.string().required('Description cannot be blank'),
            
         })



    });




  return (
    <div className="foi-header landing-header " id="loginpagebg" style={{backgroundImage:`url(${backgroudimg1}),url(${payment})`}}>
        <div className='container'>
            <div className="row">
                <div className="col-md-4 offset-md-4">
                    <div className='card'>
                        <div className="text-white  mb-2 p-2 rounded text-center" style={{ background: "indigo" }}>
                            <h4>Make Payment</h4>
                            {
                                err != '' ? <span className='text-center alert alert-danger'>{err}</span> : <span></span>
                            }
                        </div>
                        <span className='text-center text-danger'>{err}</span> <br></br>
                        <form onSubmit={formik.handleSubmit}>

                        <div className="row">
                <div className="col text-center mb-2">
                  {
                    formik.errors.cardNo && formik.touched.cardNo ?
                      <TextField sx={{ width: '35ch' }}
                        name='cardNo' id="cardNo" error
                        label="Card No*"
                        
                        
                        aria-readonly value={formik.initialValues.cardNo}
                      /> : <TextField sx={{ width: '35ch' }} aria-readonly value={formik.initialValues.cardNo}  name='cardNo' id="cardNo" label="Card No" variant="outlined" />
                  }
                </div>
              </div>
                            <div className="row">
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }} onBlur={formik.handleBlur} onChange={formik.handleChange} name='transactionAmount' id="transactionAmount" label="Amount*" variant="outlined" />
                                    {
                                        formik.errors.transactionAmount && formik.touched.transactionAmount ?
                                            <p className='text-danger'>{formik.errors.transactionAmount}</p> : null
                                    }
                                </div>
                            </div>

                            <div className="row">
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }}onBlur={formik.handleBlur} onChange={formik.handleChange} name='transactionDesc' id="transactionDesc" label="Description*" variant="outlined" />
                                    {
                                        formik.errors.transactionDesc && formik.touched.transactionDesc ?
                                            <p className='text-danger'>{formik.errors.transactionDesc}</p> : null
                                    }
                                </div>
                            </div>

                            
          
                            <div className="row">
                                <div className="col text-center mb-4 ">
                                    <div className='font-weight-bold'>
                                    <Button type='submit' variant="contained" id="mainbutton1" style={{background:"indigo",fontWeight:"bold" }}>Pay</Button>
                                </div>
                                </div>
                            </div>

                        </form>

                    </div>
                    <br></br>
                    <Snackbar
                        open={open}
                        autoHideDuration={2000}
                        onClose={handleClose}
                        message="Payment successfully"
                        action={action}
                    />
                </div>
            </div>
        </div>
        </div>
    )
}
