import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'


import { Link } from 'react-router-dom';
export default function Transaction() {

  const token = localStorage.getItem("mytoken");
  const customerId = localStorage.getItem("customerId");
  const [transactionarray, setTransactionarray] = useState([]);
  const [err, setErr] = useState('')
  useEffect(() => {
    fetch(`http://localhost:8080/api/accounts/getaccount/${customerId}`, {
        headers: {
            'Content-Type': 'application/json',
            "Authorization": `Bearer ${token}`
               
        }
    })
        .then(res => res.json())
        .then((data) => {
          console.log("account", data)
            localStorage.setItem('accountNo', data[0].accountNo);
            localStorage.setItem("userData",JSON.stringify(data))
        }).then(()=>{
          fetch(`http://localhost:8080/api/card/getcard/${localStorage.getItem('accountNo')}`, {
            headers: {
                'Content-Type': 'application/json',
                "Authorization": `Bearer ${token}`
            }
        })
            .then(res => res.json())
            .then((data) => {
              console.log("card", data)
                localStorage.setItem("userData",JSON.stringify(data))
                localStorage.setItem('cardNo', data[0].cardNo);
            })
            .then(()=>{
              fetch(`http://localhost:8080/api/transaction/gettransaction/${localStorage.getItem('cardNo')}`, {
               
                headers: {
                    'Content-Type': 'application/json',
                    "Authorization": `Bearer ${token}`
                }
            })
                
            .then(res => res.json())
            .then((data) => {
              console.log("transaction", data)
                //localStorage.setItem("TransactionData",JSON.stringify(data))
                //localStorage.setItem('cardNo', data[0].cardNo);
                 //.then(response => {
                 setTransactionarray(data);
                 //console.log("transaction1", transactionarray)
                // localStorage.setItem("transactionData",response.data)
                    
                })
              })
        })
  },)
 
  useEffect(() => {
    let trnarray = transactionarray.map(obj => obj.transactionAmount)
  
    return () => {
      function totaldBalance(total , trnarray) {
        total+=trnarray;
        return total;
    }
    //var b= (trnarray.reduce(totaldBalance))
    console.log(trnarray);
    }
  }, [])
  
 
    return (
      <div>
    <div className='card'>
      <div className='row'>
        <div className="col-md-8 offset-md-2">
          <div className="mt-2 text-center rounded p-2" >
            <h4 className='' style={{ color: "indigo" }}>Transaction details</h4>
          </div>
        </div>
      </div>
      <div className='row'>
        <div className="col-md-4 ">

          <span className='text-danger text-center'>{err}</span>

        </div>
      </div>
      <div className="row">
        <div className="col-md-8 offset-md-2">
          <table className='table table-striped text-center'>
            <thead style={{ color: "indigo" }}>
              <tr>
                
                <th>Card No</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Description</th>
                

              </tr>
            </thead>
            <tbody>
              {
                transactionarray.map(data =>
                  <tr key={data.transactionId}>
                   
                    <td>{data.cardNo}</td>
                    <td>{data.transactionType}</td>
                    <td>{data.transactionAmount}</td>
                    <td>{data.transactionDate}</td>
                    <td>{data.transactionDesc}</td>
                    
                  </tr>
                )
              }
            </tbody>
          </table>
        </div>
      </div>
      </div>
      </div>
  )
}