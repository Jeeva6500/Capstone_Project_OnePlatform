import React from 'react'
import Footer_bg from "../Images/Footer_bg.svg"
import ios from "../Images/ios.svg"
import android from "../Images/android.svg"
import payprologo from "../Images/payprologo.jpg"
import facebook from "../Images/facebook.svg"
import instagram from "../Images/instagram.svg"
import twitter from "../Images/twitter.svg"
import youtube from "../Images/youtube.svg"

export default function Footer () {

    return (
      <div>
         {!localStorage.getItem("mytoken") ?
                <>
        <footer class="foi-footer text-white" style={{backgroundImage:`url(${Footer_bg})`}}>
        <div class="container">
            <div class="row footer-content">
                <div class="col-xl-6 col-lg-7 col-md-8">
                    <h2 class="mb-0">Do you want to know more or just have a question? write to us.</h2>
                </div>
                <div class="col-md-4 col-lg-5 col-xl-6 py-3 py-md-0 d-md-flex align-items-center justify-content-end">
                    <a href="/contactform" class="btn btn-danger btn-lg">Contact form</a>
                </div>
            </div>
            <div class="row footer-widget-area">
                <div class="col-md-3">
                    <div class="py-3">
                    <img src={payprologo} style={{ height: '5vh', width: "7vw" }}alt="PayPro" id='payprologo' />
                    </div>
                    <p class="font-os font-weight-semibold mb3" id='nav-link-footer-2'>Get our mobile app</p>
                    <div>
                        <button class="btn btn-app-download mr-2"><img src= {ios} alt="App store"/></button>
                        <button class="btn btn-app-download"><img src={android} alt="play store"/></button>
                    </div>
                </div>
                <div class="col-md-3 mt-3 mt-md-0">
                    <nav>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>Account</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>My tasks</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>Projects</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>Edit profile</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>Activity</a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="col-md-3 mt-3 mt-md-0">
                    <nav>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>About</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>Services</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>Careers <span class="badge badge-pill badge-secondary ml-3">Hiring</span></a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>News</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>Community</a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="col-md-3 mt-3 mt-md-0">
                    <p>
                        &copy; 2020 <a href="https://www.bootstrapdash.com" target="_blank" rel="noopener noreferrer" class="text-reset">PayPro Fintech Ltd</a>.
                    </p>
                    <p>All rights reserved.</p>
                    <nav class="social-menu">
                        <a href="#!"><img src={facebook} alt="facebook"/></a>
                        <a href="#!"><img src= {instagram} alt="instagram"/></a>
                        <a href="#!"><img src={twitter} alt="twitter"/></a>
                        <a href="#!"><img src={youtube} alt="youtube"/></a>
                    </nav>
                </div>
            </div>
        </div>
      </footer>
      </>
      : null}

{localStorage.getItem("mytoken") ?
                <>
<footer class="foi-footer" style={{background:"indigo"}} id = "Footersizereduce">
        <div class="container">
            <div class="row footer-content">
                <div class="col-xl-6 col-lg-7 col-md-8">
                    <h2 class="mb-0 text-light">Do you have a query? write to us.</h2>
                </div>
                <div class="col-md-4 col-lg-5 col-xl-6 py-3 py-md-0 d-md-flex align-items-center justify-content-end">
                    <a href="/contactform" class="btn btn-danger btn-lg">Contact form</a>
                </div>
            </div>
            <div class="row footer-widget-area">
                <div class="col-md-3">
                    <div class="py-3">
                    <img src={payprologo} style={{ height: '5vh', width: "7vw" }}alt="PayPro" id='payprologo' />
                    </div>
                    <p class="font-os font-weight-semibold mb3" id='nav-link-footer-2'>Get our mobile app</p>
                    <div>
                        <button class="btn btn-app-download mr-2"><img src= {ios} alt="App store"/></button>
                        <button class="btn btn-app-download"><img src={android} alt="play store"/></button>
                    </div>
                </div>
                <div class="col-md-3 mt-3 mt-md-0">
                    <nav>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>Profile</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>My tasks</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>My offers</a>
                            </li>
                            
                        </ul>
                    </nav>
                </div>
                <div class="col-md-3 mt-3 mt-md-0">
                    <nav>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>Reports</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>Card Lost</a>
                            </li>
                            <li class="nav-item">
                                <a href="#!" class="nav-link" id='nav-link-footer-1'>Statement</a>
                            </li>
                           
                        </ul>
                    </nav>
                </div>
                <div class="col-md-3 mt-3 mt-md-0">
                    <p>
                        &copy; 2020 <a href="https://www.bootstrapdash.com" target="_blank" rel="noopener noreferrer" class="text-reset">PayPro Fintech Ltd</a>.
                    </p>
                    <p>All rights reserved.</p>
                    <nav class="social-menu">
                        <a href="#!"><img src={facebook} alt="facebook"/></a>
                        <a href="#!"><img src= {instagram} alt="instagram"/></a>
                        <a href="#!"><img src={twitter} alt="twitter"/></a>
                        <a href="#!"><img src={youtube} alt="youtube"/></a>
                    </nav>
                </div>
            </div>
        </div>
      </footer>
      </>
                : null}
      </div>
      
    )
  }

