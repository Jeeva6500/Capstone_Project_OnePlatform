// import React from 'react'
import { Button, FilledInput, FormControl, IconButton, InputAdornment, InputLabel, OutlinedInput, Snackbar, TextField } from '@mui/material'
import axios from 'axios'
import backgroudimg1 from "../Images/bg_1@2x.png"
import addaccount from "../Images/addaccount.jpg"
import { useFormik } from 'formik'
import React, { useState } from 'react'
import * as yup from 'yup'
import { useNavigate } from 'react-router-dom'
import CloseIcon from '@mui/icons-material/Close'
import YupPassword from 'yup-password'
YupPassword(yup)


export default function AddAccount() {
    const token = localStorage.getItem("mytoken");
    const nav = useNavigate();
    const [error, setError] = useState('')
    const navigate = useNavigate();
    const [err, setErr] = useState('');
    const [open, setOpen] = useState(false);
  
    const handleClose = () => {
        setOpen(false)
        nav('/accounts')
        return;
    }

    const action = (
        <React.Fragment>
            <IconButton size='small' color='inherit' onClick={handleClose}>
                <CloseIcon></CloseIcon>
            </IconButton>
        </React.Fragment>
    )

    const formik = useFormik({
        initialValues: {
            accountNo: '',
            accountType: '',
            bankName: '',
            ifscCode: '',
            balance:'50000',
            customerId: (localStorage.getItem('customerId')),

           

        },
        onSubmit: values => {
                                axios.post("http://localhost:8080/api/accounts/add",values, {
                                headers: {
                                "Authorization": `Bearer ${token}`
                                 }
                                    })
                                        .then(result => {
                                            //this.setState({setExist:result.data})
                                            //console.log("else executed");
                                            setOpen(true)
                                        })
                                        .catch(error => {
                                            console.log(error);
                                            setError(error.response.data)});
                                    
        },
        validationSchema: yup.object().shape({
            accountNo: yup.string().min(8).max(16, "Enter valid Account number").required('Account No cannot be blank'),
            accountType: yup.string().required('Account Type number cannot be blank'),
            bankName: yup.string().required('Bank name cannot be blank'),
            ifscCode: yup.string().min(11).max(11, "Enter valid 11 digit IFSC Code").required('IFSC Code cannot be blank'),
            customerId: yup.string().min(8).max(8, "Enter valid 8 digit Customer Id").required('Customer Id cannot be blank'),
            balance:yup.string().required('Balance cannot be blank'),
         })
    })

    return (
        <div className="foi-header landing-header " id="accountpagebg" style={{backgroundImage:`url(${backgroudimg1}),url(${addaccount})`}}>
        <div className='container'>
            <div className="row">
                <div className="col-md-4 offset-md-4">
                    <div className='card'>
                        <div className="text-white  mb-2 p-2 rounded text-center" style={{ background: "indigo" }}>
                            <h4>Link account</h4>
                            {
                                err != '' ? <span className='text-center alert alert-danger'>{error}</span> : <span></span>
                            }
                        </div>
                        <span className='text-center text-danger'>{error}</span> <br></br>
                        <form onSubmit={formik.handleSubmit}>

                        <div className="row">
                            
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }} onBlur={formik.handleBlur} onChange={formik.handleChange} name='accountNo' id="accountNo" label="Account No*" variant="outlined" />
                                    {
                                        formik.errors.accountNo && formik.touched.accountNo ?
                                            <p className='text-danger'>{formik.errors.accountNo}</p> : null
                                    }
                                   
                                </div>
                            </div>

                            <div className="row">
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }} onBlur={formik.handleBlur} onChange={formik.handleChange} name='accountType' id="accountType" label="Account Type*" variant="outlined" />
                                    {
                                        formik.errors.accountType && formik.touched.accountType ?
                                            <p className='text-danger'>{formik.errors.accountType}</p> : null
                                    }
                                </div>
                            </div>

                            <div className="row">
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }} onBlur={formik.handleBlur} onChange={formik.handleChange} name='bankName' id="bankName" label="Bank Name*" variant="outlined" />
                                    {
                                        formik.errors.bankName && formik.touched.bankName ?
                                            <p className='text-danger'>{formik.errors.bankName}</p> : null
                                    }
                                </div>
                            </div>

                            <div className="row">
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }} onBlur={formik.handleBlur} onChange={formik.handleChange} name='ifscCode' id="ifscCode" label="IFSC Code*" variant="outlined" />
                                    {
                                        formik.errors.ifscCode && formik.touched.ifscCode ?
                                            <p className='text-danger'>{formik.errors.ifscCode}</p> : null
                                    }
                                </div>
                            </div>

                                 
                            <div className="row">
                                <div className="col text-center mb-4 ">
                                    <div className='font-weight-bold'>
                                    <Button type='submit' variant="contained" id="mainbutton1" style={{background:"indigo",fontWeight:"bold" }}>Add</Button>
                                </div>
                                </div>
                            </div>

                        </form>

                    </div>
                    <br></br>
                    <Snackbar
                        open={open}
                        autoHideDuration={2000}
                        onClose={handleClose}
                        message="Account added successfully"
                        action={action}
                    />
                </div>
            </div>
        </div>
        </div>
    )
}
