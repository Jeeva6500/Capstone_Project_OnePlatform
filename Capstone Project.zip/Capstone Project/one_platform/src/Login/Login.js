import { Button, IconButton, Snackbar, TextField } from '@mui/material';
import axios from 'axios';
import { useFormik } from 'formik';
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import * as yup from 'yup'
import CloseIcon from '@mui/icons-material/Close'
import backgroudimg1 from "../Images/bg_1@2x.png"
import loginimg from "../Images/login.png"

export default function Login() {

  const navigate = useNavigate();
  const [error, setError] = useState('');
  const [err, setErr] = useState('');
  const [open, setOpen] = useState(false);

  const handleClose = () => {
    setOpen(false)
    
    navigate('/dashboard')
    window.location.reload();
    return;
  }

  const action = (
    <React.Fragment>
      <IconButton size='small' color='inherit' onClick={handleClose}>
        <CloseIcon></CloseIcon>
      </IconButton>
    </React.Fragment>
  )

  const formik = useFormik({
    initialValues: {
      customerId: '',
      password: ''
    },
    onSubmit: values => {
      axios.post('http://localhost:8080/login',values)
        .then(res => {
          setOpen(true)
          console.log(res);
          
          localStorage.setItem('mytoken',res.data.token);
          localStorage.setItem('customerId', res.data.customerId)
          
          

        })
        .catch(error => setError(error.message))
    },
    validationSchema: yup.object().shape({
      customerId: yup.string().min(8).max(8, 'Enter the valid customer Id').required('Field cannot be blank'),
      password: yup.string().required('Field cannot be blank')

    })
  })
  return (
    <div className="foi-header landing-header mt-4" id="loginpagebg" style={{backgroundImage:`url(${backgroudimg1}),url(${loginimg})`}}>
    <div className='container mt-6'>
      <div className="row">
        <div className="col-md-4 offset-md-4 mb-4">
          <div className='card'>
            <div className="text-white  mb-2 p-2 rounded text-center" style={{ background: "indigo" }}>
              <h4>Login</h4>
            </div>
            <span className='text-center text-danger'>{err}</span>
            {
              error != '' ? <span className="text-center text-danger">Invalid credentials!</span> : <span></span>
            }
            <form onSubmit={formik.handleSubmit}>
              <div className="row">
                <div className="col text-center mb-2 mt-4">


                  {
                    formik.errors.customerId && formik.touched.customerId ?
                      <TextField sx={{ width: '35ch' }} onBlur={formik.handleBlur} onChange={formik.handleChange}
                        name='customerId' id="customerId" error
                        label="Customer-Id*"
                        helperText={formik.errors.customerId}
                      /> : <TextField sx={{ width: '35ch' }} onBlur={formik.handleBlur} onChange={formik.handleChange} name='customerId' id="customerId" label="Customer-Id*" variant="outlined" />
                  }
                </div>
              </div>

              <div className="row">
                <div className="col text-center mb-2">
                  <TextField sx={{ width: '35ch' }} onBlur={formik.handleBlur} onChange={formik.handleChange} name='password' id="password" type="password" label="Password*" variant="outlined" />
                  {
                    formik.errors.password && formik.touched.password ?

                      <p className='text-danger me-4'>{formik.errors.password}</p> : null
                  }
                </div>
              </div>
              <div className="row">
                <div className="col text-center mb-4">
                  <Button type='submit' variant="contained" id= "mainbutton1" style={{background:"indigo",fontWeight:"bold"}}>Login</Button>
                </div>
              </div>
            </form>
          </div>
          <Snackbar
            open={open}
            autoHideDuration={2000}
            onClose={handleClose}
            message="Login success"
            action={action}
          />
        </div>
      </div>
    </div>
    </div>
    
  )
}

