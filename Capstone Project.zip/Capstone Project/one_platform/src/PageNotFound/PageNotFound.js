import React, { PureComponent } from 'react'
export default class PageNotFound extends PureComponent {
  render() {
    return (
        <div>
        <section className="error-area error-one mt-5">
   <div className="container mb-5">
      <div className="row justify-content-center">
         <div className="col-xxl-7 col-xl-8 col-lg-8">
            <div className="error-content text-center">
               <span className="error-404">404</span>
               <h1 className="sub-title">Oops! The page you are looking for could not be found.</h1>
               <h4 className="text pt-2" >
               It may have been removed, had it's name changed, or is temporarily unavailable.
               </h4>
               <div className="error-form mt-3">
                  <form action="#0">
                     <i className="lni lni-search-alt"></i>
                     <input type="text" id = "pagenotfoundtext" placeholder="Search for page"/>
                     <div className="error-btn rounded-buttons mt-3">
                        <button className="btn danger-btn rounded-full text-light" style={{background: "indigo"}} type="submit">Search</button>
                     </div>
                  </form>
               </div>
            </div>
            
         </div>
      </div>
   </div>
</section>
      </div>
    )
  }
}
