import React from "react";
import { Suspense } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Accounts from "./Accounts/Accounts";
import './App.css';


import Dashboard from "./Dashboard/Dashboard";

import Footer from "./Footer/Footer";
import Header from "./Header/Header";
import Home from "./Home/Home";
import Login from "./Login/Login";
import PageNotFound from "./PageNotFound/PageNotFound";
import Register from "./Register/Register";

import Transaction from "./Transaction/Transaction";


import Profile from "./Profile/Profile";

import ContactForm from "./ContactForm/ContactForm";
import AddAccount from "./AddAccount/AddAccount";
import AddCard from "./AddCard/AddCard";
import MakePayment from "./MakePayment/MakePayment";
import AboutUs from "./AboutUs/AboutUs";


function App() {
  return (
    <div>
<BrowserRouter>
<Suspense fallback= {<div><h3 className='alert alert-dange text-center'>Loading...</h3></div>}>
<Header />
<Routes>
<Route path="/" element={<Home />}></Route>
<Route path="/home" element={<Home />}></Route>
<Route path="/aboutus" element={<AboutUs />}></Route>
<Route path="/login" element={<Login />}></Route>
<Route path="/register" element={<Register />}></Route>
<Route path="/dashboard" element={<Dashboard />}></Route>
<Route path="/accounts" element={<Accounts />}></Route>
<Route path="/contactform" element={<ContactForm />}></Route>
<Route path="*" element={<PageNotFound />}></Route>
<Route path="/transaction" element={<Transaction />}></Route>

<Route path="/profile" element={<Profile />}></Route>
<Route path="/contactform" element={<ContactForm />}></Route>
<Route path="/addaccount" element={<AddAccount />}></Route>
<Route path="/addcard" element={<AddCard />}></Route>
<Route path="/makepayment" element={<MakePayment />}></Route>

</Routes>
<Footer />
</Suspense>
</BrowserRouter>


    </div>
  );
}

export default App;
