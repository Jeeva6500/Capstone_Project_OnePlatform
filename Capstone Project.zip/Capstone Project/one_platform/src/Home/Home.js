import React from 'react'
import app_2 from "../Images/app_2.png"
import axis from "../Images/axis.jpg"
import hdfc from "../Images/hdfc.jpg"
import sbi from "../Images/sbi.jpg"
import icici3 from "../Images/icici3.jpg"
import yes from "../Images/yes.jpg"
import pnb from "../Images/pnb.jpg"
import ajay from "../Images/ajay.jpg"
import payal from "../Images/payal.jpg"
import prabha from "../Images/prabha.JPG"
import padmaji from "../Images/padmaji.jpg"
import backgroudimg1 from "../Images/bg_1@2x.png"
import backgroundimg2 from "../Images/Bg_2@2x.png"
import ios from "../Images/ios.svg"
import android from "../Images/android.svg"
import app_3 from "../Images/app_3.gif"


export default function Home() {
 
    return (
         <div className='container-fluid'>
        <div className="foi-header landing-header" style={{backgroundImage:`url(${backgroudimg1}), url(${backgroundimg2})`}}>
            <div className="header-content">
                <div className="row" id='hometext1'>
                    <div className="col-md-6 ">
                        <h1>Great app that manages all your accounts</h1>
                        <p className="text-dark">Customers can access and manage all their bank accounts, Credit cards and Investments on the go. PayPro facilitates seamless financial transactions without any charges to customers.</p>
                        <a className="btn btn-primary mb-4" href="https://apps.apple.com/us/app/paypro/id1213703998">Get Started</a>
                        <div className="my-2">
                            <p className="header-app-download-title">GET OUR MOBILE APP</p>
                        </div>
                        <div>
                            <button className="btn btn-app-download mr-2"><img src={ios} alt="App store"/></button>
                            <button className="btn btn-app-download"><img src= {android} alt="play store"/></button>
                        </div>
                    </div>
                    <div className="col-md-6" id='headergif1'>
                    <img src={app_3} alt="app" style={{ height: '55vh', width: "15vw" }} className="img-fluid"/>
                    </div>
                </div>
                </div>
                </div>
        <div class="container">
            <section class="py-3 ">
            <h2 class="section-title">Application Features</h2>
            <div class="row">
                <div class="col-lg-4 mb-4 mb-lg-0">
                    <h5>Secure Data</h5>
                    <p class="text-dark">Your financial data and credentials are highly secured. Certified for best security by IBM.</p>
                    <p class="mb-5"><a href="#!" class="text-primary mb-5">Find out More</a></p>
                    <h5>Fully functional</h5>
                    <p class="text-dark">App will function without any interupption. Money will back in case transaction failed.</p>
                    <p class="mb-5"><a href="#!" class="text-primary mb-5">Find out More</a></p>
                </div>
                <div class="col-lg-4 mb-3 mb-lg-0">
                    <h5>Live support</h5>
                    <p class="text-dark">24/7 support to all customers. Live support available in all regional languages in India. </p>
                    <p class="mb-5"><a href="#!" class="text-primary mb-5">Find out More</a></p>
                    <h5>Powerful dashboard</h5>
                    <p class="text-dark">Fully sophisticated dashboard will help you to navigate all your accounts seamlessly .</p>
                    <p class="mb-5"><a href="#!" class="text-primary mb-5">Find out More</a></p>
                </div>
                <div class="col-lg-4">
                    <h6 class="text-gray font-os font-weight-semibold">Trusted by the India's best</h6>
                    <div id="landingClientCarousel" class="carousel slide landing-client-carousel" data-ride="carousel">
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active">
                                <div class="d-flex flex-wrap justify-content-center">
                                    <div class="clients-logo">
                                        <img src={axis} style={{ height: '6vh', width: "6vw" }}alt="Axis" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={hdfc}  style={{ height: '6vh', width: "6vw" }} alt="HDFC" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={sbi} style={{ height: '6vh', width: "6vw" }} alt="SBI" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={icici3}  style={{ height: '6vh', width: "6vw" }} alt="ICICI" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={yes}  style={{ height: '6vh', width: "6vw" }} alt="Yes" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={pnb} style={{ height: '6vh', width: "6vw" }}alt="PNB" class="img-fluid"/>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="d-flex flex-wrap justify-content-center">
                                <div class="clients-logo">
                                        <img src={axis} style={{ height: '6vh', width: "6vw" }}alt="Axis" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={hdfc}  style={{ height: '6vh', width: "6vw" }} alt="HDFC" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={sbi} style={{ height: '6vh', width: "6vw" }} alt="SBI" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={icici3}  style={{ height: '6vh', width: "6vw" }} alt="ICICI" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={yes}  style={{ height: '6vh', width: "6vw" }} alt="Yes" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={pnb} style={{ height: '6vh', width: "6vw" }}alt="PNB" class="img-fluid"/>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="d-flex flex-wrap justify-content-center">
                                <div class="clients-logo">
                                        <img src={axis} style={{ height: '6vh', width: "6vw" }}alt="Axis" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={hdfc}  style={{ height: '6vh', width: "6vw" }} alt="HDFC" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={sbi} style={{ height: '6vh', width: "6vw" }} alt="SBI" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={icici3}  style={{ height: '6vh', width: "6vw" }} alt="ICICI" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={yes}  style={{ height: '6vh', width: "6vw" }} alt="Yes" class="img-fluid"/>
                                    </div>
                                    <div class="clients-logo">
                                        <img src={pnb} style={{ height: '6vh', width: "6vw" }}alt="PNB" class="img-fluid"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <ol class="carousel-indicators">
                            <li data-target="#landingClientCarousel" data-slide-to="0" class="active"></li>
                            <li data-target="#landingClientCarousel" data-slide-to="1"></li>
                            <li data-target="#landingClientCarousel" data-slide-to="2"></li>
                        </ol>
                    </div>
                    </div>
                    </div>
                    </section>
        
           
           
            <section class="py-3 ">
            <div class="container">
            <div class="row">
                <div class="col-md-6 mb-5 mb-md-0">
                    <img src={app_2} alt="Banking app" class="img-fluid" width="492px"/>
                </div>
                <div class="col-md-6">
                    <h2 class="section-title">Rewards that are endlessly rewarding</h2>
                    <p class="mb-5">Earn scratch cards and other rewards as you use PayPro worth up to ₹1,00,000*. You don’t need to hunt for coupon codes.If you win, your rewards go straight into your bank account.</p>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <div class="media landing-feature">
                                <span class="landing-feature-icon"></span>
                                <div class="media-body">
                                    <h5>No charges</h5>
                                    <p>Pay and receive money instantly using your existing bank accounts. No more reloading mobile wallet balances or withdrawal charges.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="media landing-feature">
                                <span class="landing-feature-icon"></span>
                                <div class="media-body">
                                    <h5>Exciting offers</h5>
                                    <p>Use PayPro wallet at selected metchants across India to win 1% cashback on your transactions. No cap in cashback earnings.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="media landing-feature">
                                <span class="landing-feature-icon"></span>
                                <div class="media-body">
                                    <h5>Dinning anytime</h5>
                                    <p>Dinning made simple with 10% cashback at all our partnered restaurents across India. Cashback will be credited immediately.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="py-4">
        <div class="container">
            <h2>Choose our range of co-branded Credit cards</h2>
            <p class="text-muted mb-3">You can easily apply for a Credit card in few steps without visiting to any Bank website.  </p>
            <div class="row">
                <div class="col-lg-4 ">
                    <div class="card pricing-card border-warning">
                        <div class="card-body">
                            <h3 class="mb-1">PayPro Cashback Card</h3>
                            <h3 class="mb-1 text-warning">Free</h3>
                            <p class="payment-period">Rs.499 renewal fee per year</p>
                            <p class="mb-4">You can get flat 1% cashback on all your spends excluding fuel transactions.</p>
                            <button class="btn btn-outline-warning btn-rounded">Apply now</button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card pricing-card border-primary active">
                        <div class="card-body">
                            <h3>HDFC Paypro Miles</h3>
                            <h3 class="text-primary">Rs.999</h3>
                            <p class="payment-period">Rs.1299 renewal fee per year</p>
                            <p class="mb-4">You can earn 2miles per every 150spend. No cap in earning. 4 Free lounge access.</p>
                            <button class="btn btn-primary btn-rounded">Apply now</button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card pricing-card border-success">
                        <div class="card-body">
                            <h3>Axis PayPro Black</h3>
                            <h3 class="text-success">Rs.1599</h3>
                            <p class="payment-period">Rs.1999 renewal fee per year</p>
                            <p class="mb-4">Unlimited 2% cashback on all transactions. 10 free launge access. 20% cashback on dinning.</p>
                            <button class="btn btn-outline-success btn-rounded">Apply now</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="py-4">
        <div class="container">
            <h2>Customer feedback</h2>
            <p class="text-muted mb-3">Thank you for such a flexible and convenient app to make our life simple. </p>
            <div class="row">
                <div class="col-md-4 foi-review mb-5 mb-md-0">
                    <div class="foi-rating">
                        <span class="fas fa-star checked"></span>
                        <span class="fas fa-star checked"></span>
                        <span class="fas fa-star checked"></span>
                        <span class="fas fa-star checked"></span>
                        <span class="fas fa-star checked"></span>
                    </div>
                    <h5 class="foi-review-heading">Great support</h5>
                    <p class="foi-review-content">Thanks to PayPro team for your professional and on-time support on my failed transaction. I got my money back within 10mins.</p>
                    <div class="media foi-review-user">
                        <img src={payal} alt="user" class="avatar"/>
                        <div class="media-body">
                            <h6 class="mb-0">Payal Dedhia</h6>
                            <p>Blogger & Trainer</p>
                        </div>
                    </div>

                </div>
                <div class="col-md-4 foi-review mb-5 mb-md-0">
                    <div class="foi-rating">
                        <span class="fas fa-star checked"></span>
                        <span class="fas fa-star checked"></span>
                        <span class="fas fa-star checked"></span>
                        <span class="fas fa-star checked"></span>
                        <span class="fas fa-star checked"></span>
                    </div>
                    <h5 class="foi-review-heading">Amazing co-branded cards</h5>
                    <p class="foi-review-content">Am using Axis PayPro Black credit card for last 2 years. It is acceptable everywhere and am excited with the cashbach earning.</p>
                    <div class="media foi-review-user">
                        <img src={ajay} alt="user" class="avatar"/>
                        <div class="media-body">
                            <h6 class="mb-0">Ajay Sharma</h6>
                            <p>Software Engineer</p>
                        </div>
                    </div>

                </div>
                <div class="col-md-4 foi-review mb-5 mb-md-0">
                    <div class="foi-rating">
                        <span class="fas fa-star checked"></span>
                        <span class="fas fa-star checked"></span>
                        <span class="fas fa-star checked"></span>
                        <span class="fas fa-star checked"></span>
                        <span class="fas fa-star checked"></span>
                    </div>
                    <h5 class="foi-review-heading">Very convenient dashboard</h5>
                    <p class="foi-review-content">PayPro dashboard provides sophisticated view of all my transactions. Am happy to access my accounts in a single platform on the go. </p>
                    <div class="media foi-review-user">
                        <img src={padmaji} alt="user" class="avatar"/>
                        <div class="media-body">
                            <h6 class="mb-0">Padmaji Tangella</h6>
                            <p>Banking Professional</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <section class="py-5 mb-5">
        <div class="container">
            <h2>FAQ</h2>
            <p class="section-subtitle">Frequently Asked Questions</p>
            <div class="row">
                <div class="col-lg-6">
                    <div class="card mb-3 landing-faq-card">
                        <div class="card-header bg-white" id="faqOneTitle">
                            <a href="#faqOneCollapse" class="d-flex align-items-center" data-toggle="collapse">
                                <h6 class="mb-0">What is PayPro app?</h6> <i class="far fa-plus-square ml-auto"></i>
                            </a>
                        </div>
                        <div id="faqOneCollapse" class="collapse" aria-labelledby="faqOneTitle">
                            <div class="card-body">
                                <p class="mb-0 text-gray">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                            </div>
                        </div>
                    </div>
                    <div class="card mb-3 landing-faq-card">
                        <div class="card-header bg-white" id="faqTwoTitle">
                            <a href="#faqTwoCollapse" class="d-flex align-items-center" data-toggle="collapse">
                                <h6 class="mb-0">Why should I use PayPro app?</h6> <i class="far fa-plus-square ml-auto"></i>
                            </a>
                        </div>
                        <div id="faqTwoCollapse" class="collapse" aria-labelledby="faqTwoTitle">
                            <div class="card-body">
                                <p class="mb-0 text-gray">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                            </div>
                        </div>
                    </div>
                    <div class="card mb-3 landing-faq-card">
                        <div class="card-header bg-white" id="faqThreeTitle">
                            <a href="#faqThreeCollapse" class="d-flex align-items-center" data-toggle="collapse">
                                <h6 class="mb-0">How can I use PayPro app?</h6> <i class="far fa-plus-square ml-auto"></i>
                            </a>
                        </div>
                        <div id="faqThreeCollapse" class="collapse" aria-labelledby="faqThreeTitle">
                            <div class="card-body">
                                <p class="mb-0 text-gray">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card mb-3 landing-faq-card">
                        <div class="card-header bg-white" id="faqFourTitle">
                            <a href="#faqFourCollapse" class="d-flex align-items-center" data-toggle="collapse">
                                <h6 class="mb-0">Can I access my Credit cards?</h6> <i class="far fa-plus-square ml-auto"></i>
                            </a>
                        </div>
                        <div id="faqFourCollapse" class="collapse" aria-labelledby="faqFourTitle">
                            <div class="card-body">
                                <p class="mb-0 text-gray">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                            </div>
                        </div>
                    </div>
                    <div class="card mb-3 landing-faq-card">
                        <div class="card-header bg-white" id="faqFiveTitle">
                            <a href="#faqFiveCollapse" class="d-flex align-items-center" data-toggle="collapse">
                                <h6 class="mb-0">How to contact support centre?</h6> <i class="far fa-plus-square ml-auto"></i>
                            </a>
                        </div>
                        <div id="faqFiveCollapse" class="collapse" aria-labelledby="faqFiveTitle">
                            <div class="card-body">
                                <p class="mb-0 text-gray">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                            </div>
                        </div>
                    </div>
                    <div class="card mb-3 landing-faq-card">
                        <div class="card-header bg-white" id="faqSixTitle">
                            <a href="#faqSixCollapse" class="d-flex align-items-center" data-toggle="collapse">
                                <h6 class="mb-0">Can I use this app to make Bill payments?</h6> <i class="far fa-plus-square ml-auto"></i>
                            </a>
                        </div>
                        <div id="faqSixCollapse" class="collapse" aria-labelledby="faqSixTitle">
                            <div class="card-body">
                                <p class="mb-0 text-gray">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </div>
      </div>
     
    )
  }
