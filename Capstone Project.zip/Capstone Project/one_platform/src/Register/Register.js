// import React from 'react'
import { Button, FilledInput, FormControl, IconButton, InputAdornment, InputLabel, OutlinedInput, Snackbar, TextField } from '@mui/material'
import axios from 'axios'
import backgroudimg1 from "../Images/bg_1@2x.png"
import Registerimg from "../Images/Register.png"
import { useFormik } from 'formik'
import React, { useState } from 'react'
import * as yup from 'yup'
import { useNavigate } from 'react-router-dom'
import CloseIcon from '@mui/icons-material/Close'
import YupPassword from 'yup-password'
YupPassword(yup)


export default function Register() {

    const nav = useNavigate();
    const [error, setError] = useState('')
    const navigate = useNavigate();
    const [err, setErr] = useState('');
    const [open, setOpen] = useState(false);
    const [exist, setExist] = useState('');

    const handleClose = () => {
        setOpen(false)
        nav('/login')
        return;
    }

    const action = (
        <React.Fragment>
            <IconButton size='small' color='inherit' onClick={handleClose}>
                <CloseIcon></CloseIcon>
            </IconButton>
        </React.Fragment>
    )

    const formik = useFormik({
        initialValues: {
            name: '',
            password: '',
            email: '',
            phone: '',
            pan: '',
            confirmPassword: ''

        },
        onSubmit: values => {
                                    axios.post('http://localhost:8080/api/user/add', values)
                                        .then(result => {
                                            //this.setState({setExist:result.data})
                                            //console.log("else executed");
                                            setOpen(true)
                                            localStorage.setItem('Name', result.data.name);
                                            
                                        })
                                        .catch(error => {
                                            console.log(error);
                                            setError(error.response.data)});
                                    
        },
        validationSchema: yup.object().shape({
            name: yup.string().required('Name cannot be blank'),
            password: yup.string().password("Password should be minimum 8 characters").required('Password cannot be blank'),
            email: yup.string().email('Enter valid email id').required('Email id cannot be blank'),
           phone: yup.string().min(10).max(10, "Enter valid phone number").required('Phone number cannot be blank'),
            pan: yup.string().min(10).max(10, "Enter valid 10 digit PAN number").required('PAN number cannot be blank'),
        confirmPassword: yup.string().required("Confirm password cannot be blank")
        .test("confirmPassword","Password and Confirm password should be same", function (cpass) {
        if (this.parent.password === cpass) {
        return true;
        } return false;
        })
        })
    })

    return (
        <div className="foi-header landing-header " id="loginpagebg" style={{backgroundImage:`url(${backgroudimg1}),url(${Registerimg}))`}}>
        <div className='container'>
            <div className="row">
                <div className="col-md-4 offset-md-4">
                    <div className='card'>
                        <div className="text-white  mb-2 p-2 rounded text-center" style={{ background: "indigo" }}>
                            <h4>Tell us about you</h4>
                            {
                                err != '' ? <span className='text-center alert alert-danger'>{error}</span> : <span></span>
                            }
                        </div>
                        <span className='text-center text-danger'>{error}</span> <br></br>
                        <form onSubmit={formik.handleSubmit}>

                        <div className="row">
                            
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }}onBlur={formik.handleBlur} onChange={formik.handleChange} name='phone' id="phone" label="Mobile number*" variant="outlined" />
                                    {
                                        formik.errors.phone && formik.touched.phone ?
                                            <p className='text-danger'>{formik.errors.phone}</p> : null
                                    }
                                   
                                </div>
                            </div>

                            <div className="row">
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }}onBlur={formik.handleBlur} onChange={formik.handleChange} name='name' id="name" label="Name*" variant="outlined" />
                                    {
                                        formik.errors.name && formik.touched.name ?
                                            <p className='text-danger'>{formik.errors.name}</p> : null
                                    }
                                </div>
                            </div>

                            <div className="row">
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }}onBlur={formik.handleBlur} onChange={formik.handleChange} name='email' id="email" label="Email Id*" variant="outlined" />
                                    {
                                        formik.errors.email && formik.touched.email ?
                                            <p className='text-danger'>{formik.errors.email}</p> : null
                                    }
                                </div>
                            </div>

                            <div className="row">
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }}onBlur={formik.handleBlur} onChange={formik.handleChange} name='pan' id="pan" label="PAN number*" variant="outlined" />
                                    {
                                        formik.errors.pan && formik.touched.pan ?
                                            <p className='text-danger'>{formik.errors.pan}</p> : null
                                    }
                                </div>
                            </div>
                            
                            <div className="row">
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }}onBlur={formik.handleBlur} onChange={formik.handleChange} name='password' id="password" type="password" label="Password*" variant="outlined" />
                                    {
                                        formik.errors.password && formik.touched.password ?
                                            <p className='text-danger'>{formik.errors.password}</p> : null
                                    }
                                </div>
                            </div>

                            <div className="row">
                                <div className="col text-center mb-2">
                                    <TextField sx={{ width: '35ch' }}onBlur={formik.handleBlur} onChange={formik.handleChange} name='confirmPassword' id="confirmPassword" type="password" label="Confirm password*" variant="outlined" />
                                    {
                                        formik.errors.confirmPassword && formik.touched.confirmPassword ?
                                            <p className='text-danger'>{formik.errors.confirmPassword}</p> : null
                                    }
                                </div>
                            </div>

                                
                            
                            <div className="row">
                                <div className="col text-center mb-4 ">
                                    <div className='font-weight-bold'>
                                    <Button type='submit' variant="contained" id="mainbutton1" style={{background:"indigo",fontWeight:"bold" }}>Register</Button>
                                </div>
                                </div>
                            </div>

                        </form>

                    </div>
                    <br></br>
                    <Snackbar
                        open={open}
                        autoHideDuration={2000}
                        onClose={handleClose}
                        message="Registered Successfully. Check your registered email for Customer Id"
                        action={action}
                    />
                </div>
            </div>
        </div>
        </div>
    )
}
