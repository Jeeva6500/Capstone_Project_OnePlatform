import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

export default function Profile() {

  const token = localStorage.getItem("mytoken");
  const customerId = localStorage.getItem("customerId");
  console.log(customerId);

  const navigate = useNavigate();

  const [userarray, setUserarray] = useState([]);
  const [err, setErr] = useState('')
  

  useEffect(() => {
    axios.get(`http://localhost:8080/api/user/get/${customerId}`, {
      headers: {
        "Authorization": `Bearer ${token}`
      },

    })
      .then(result => { 
    console.log(result.data)
    setUserarray(result.data)
    console.log(userarray);
    })

      .catch(error => setErr(error.message))

  }, [])

    return (
    <div className='card'>
      <div className='row'>
        <div className="col-md-8 offset-md-2">
          <div className="mt-2 text-center rounded p-2" >
            <h4 className='' style={{ color: "indigo" }}>Profile details</h4>
          </div>
        </div>
      </div>
      <div className='row'>
        <div className="col-md-8 offset-md-2">

          <span className='text-danger text-center'>{err}</span>

        </div>
      </div>
      <div className="row">
        <div className="col-md-8 offset-md-2">
          <table className='table table-striped text-center'>
            <thead style={{ color: "indigo" }}>
              <tr>
                
                <th>Customer Id</th>
                <th>Mobile Number</th>
                <th>Name</th>
                <th>Email Id</th>
                <th>PAN Number</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                   
                    <td>{userarray.customerId}</td>
                    <td>{userarray.phone}</td>
                    <td>{userarray.name}</td>
                    <td>{userarray.email}</td>
                    <td>{userarray.pan}</td>
                    </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
