import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'


export default function Accounts() {

  const token = localStorage.getItem("mytoken");
  const customerId = localStorage.getItem("customerId");
  console.log(customerId);

  const navigate = useNavigate();

  const [accountarray, setAccountarray] = useState([]);
  const [err, setErr] = useState('')
  const [cardarray, setCardarray] = useState([]);
  const [transactionarray, setTransactionarray] = useState([]);
  let accountNo = 0;
  let cardNo = 0;

//let cardData = localStorage.getItem("transactionData");
//let x = JSON.parse(cardData);
//let debitBalance = x.map(obj => obj.transactionAmount);

//console.log(debitBalance);








  useEffect(() => {
    axios.get(`http://localhost:8080/api/accounts/getaccount/${customerId}`, {
      headers: {
        "Authorization": `Bearer ${token}`
      }
    })
      .then(result => {
        setAccountarray(result.data)
        console.log("Account data", accountarray);
        accountNo = accountarray.accountNo;
        console.log(accountNo);
        axios.get("http://localhost:8080/api/card/get", {
          headers: {
            "Authorization": `Bearer ${token}`
          }
        })
          .then(result => {
            setCardarray(result.data)
            console.log("card data", cardarray);
            cardNo = cardarray.cardNo;
            console.log(cardNo);
          })
          .catch(error => setErr(error.message))
      })
      .catch(error => setErr(error.message))
  }, [])


  return (
    <div>
    <div className='card'>
      <div className='row'>
        <div className="col-md-8 offset-md-2">
          <div className="mt-2 text-center rounded p-2" >
            <h4 className='' style={{ color: "indigo" }}>Accounts details</h4>
          </div>
        </div>
      </div>
      <div className='row'>
        <div className="col-md-4 ">

          <span className='text-danger text-center'>{err}</span>

        </div>
      </div>
      <div className="row">
        <div className="col-md-8 offset-md-2">
          <table className='table table-striped text-center'>
            <thead style={{ color: "indigo" }}>
              <tr>
                
                <th>Account No</th>
                <th>Account Type</th>
                <th>Balance</th>
                <th>Bank Name</th>
                <th>IFSC Code</th>
                

              </tr>
            </thead>
            <tbody>
              {
                accountarray.map(data =>
                  <tr key={data.accountNo}>
                   
                    <td>{data.accountNo}</td>
                    <td>{data.accountType}</td>
                    <td>{data.balance}</td>
                    <td>{data.bankName}</td>
                    <td>{data.ifscCode}</td>
                    
                  </tr>
                )
              }
            </tbody>
          </table>
        </div>
      </div>
      </div>

      <div className='card'>
      <div className='row'>
        <div className="col-md-8 offset-md-2">
          <div className="mt-2 text-center rounded p-2" >
            <h4 className='' style={{ color: "indigo" }}>Card details</h4>
          </div>
        </div>
      </div>
      <div className='row'>
        <div className="col-md-4 ">

          <span className='text-danger text-center'>{err}</span>

        </div>
      </div>
      <div className="row">
        <div className="col-md-8 offset-md-2">
          <table className='table table-striped text-center'>
            <thead style={{ color: "indigo" }}>
              <tr>
                
                <th>Card No</th>
                <th>Limit</th>
                <th>Expiry Date</th>
                <th>CVV</th>
                

              </tr>
            </thead>
            <tbody>
              {
                cardarray.map(data =>
                  <tr key={data.cardNo}>
                    
                    <td>{data.cardNo}</td>
                    <td>{data.cardLimit}</td>
                    <td>{data.expiryDate}</td>
                    <td>***</td>
                  </tr>
                )
              }
            </tbody>
          </table>
        </div>
      </div>
      </div>
    </div>
  )
}
